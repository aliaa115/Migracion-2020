﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace procesoeEntregaDePasaporte
{
    public partial class Frm_recepcion_de_pasaportes : Form
    {
        public Frm_recepcion_de_pasaportes()
        {
            InitializeComponent();
        }

        private void TableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void TableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {
                
        }
    }
}
