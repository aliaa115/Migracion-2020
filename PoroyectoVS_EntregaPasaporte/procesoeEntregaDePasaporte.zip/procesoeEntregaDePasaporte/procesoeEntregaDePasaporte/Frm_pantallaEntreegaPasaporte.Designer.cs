﻿namespace procesoeEntregaDePasaporte
{
    partial class Frm_recepcion_de_pasaportes
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_recepcion_de_pasaportes));
            this.Tlp_titulo = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_Titulo1 = new System.Windows.Forms.Label();
            this.Tlp_avance = new System.Windows.Forms.TableLayoutPanel();
            this.Pic_no2 = new System.Windows.Forms.PictureBox();
            this.Pic_no3 = new System.Windows.Forms.PictureBox();
            this.Pic_no4 = new System.Windows.Forms.PictureBox();
            this.Pic_no5 = new System.Windows.Forms.PictureBox();
            this.Pic_no1 = new System.Windows.Forms.PictureBox();
            this.Pic_barra1 = new System.Windows.Forms.PictureBox();
            this.Pic_barra2 = new System.Windows.Forms.PictureBox();
            this.Pic_barra3 = new System.Windows.Forms.PictureBox();
            this.Pic_barra4 = new System.Windows.Forms.PictureBox();
            this.Tlp_area_info = new System.Windows.Forms.TableLayoutPanel();
            this.Lbl_no_paso = new System.Windows.Forms.Label();
            this.Tlp_Informacion = new System.Windows.Forms.TableLayoutPanel();
            this.Lbl_paso_actual = new System.Windows.Forms.Label();
            this.Lbl_descripcion_paso = new System.Windows.Forms.Label();
            this.Pic_imagen_pasaporte = new System.Windows.Forms.PictureBox();
            this.Tlp_entrega_pasaporte = new System.Windows.Forms.TableLayoutPanel();
            this.Tlp_titulo.SuspendLayout();
            this.Tlp_avance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra4)).BeginInit();
            this.Tlp_area_info.SuspendLayout();
            this.Tlp_Informacion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_imagen_pasaporte)).BeginInit();
            this.Tlp_entrega_pasaporte.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tlp_titulo
            // 
            this.Tlp_titulo.ColumnCount = 3;
            this.Tlp_titulo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.Tlp_titulo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.Tlp_titulo.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.Tlp_titulo.Controls.Add(this.lbl_Titulo1, 1, 1);
            this.Tlp_titulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tlp_titulo.Location = new System.Drawing.Point(4, 4);
            this.Tlp_titulo.Margin = new System.Windows.Forms.Padding(4);
            this.Tlp_titulo.Name = "Tlp_titulo";
            this.Tlp_titulo.RowCount = 3;
            this.Tlp_titulo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.Tlp_titulo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.Tlp_titulo.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.Tlp_titulo.Size = new System.Drawing.Size(1391, 177);
            this.Tlp_titulo.TabIndex = 1;
            // 
            // lbl_Titulo1
            // 
            this.lbl_Titulo1.AutoSize = true;
            this.lbl_Titulo1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Titulo1.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Titulo1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(157)))), ((int)(((byte)(217)))));
            this.lbl_Titulo1.Location = new System.Drawing.Point(490, 35);
            this.lbl_Titulo1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Titulo1.Name = "lbl_Titulo1";
            this.lbl_Titulo1.Size = new System.Drawing.Size(409, 106);
            this.lbl_Titulo1.TabIndex = 0;
            this.lbl_Titulo1.Text = "Bienvenido";
            this.lbl_Titulo1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tlp_avance
            // 
            this.Tlp_avance.ColumnCount = 11;
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.22936F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.504587F));
            this.Tlp_avance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.22936F));
            this.Tlp_avance.Controls.Add(this.Pic_no2, 3, 1);
            this.Tlp_avance.Controls.Add(this.Pic_no3, 5, 1);
            this.Tlp_avance.Controls.Add(this.Pic_no4, 7, 1);
            this.Tlp_avance.Controls.Add(this.Pic_no5, 9, 1);
            this.Tlp_avance.Controls.Add(this.Pic_no1, 1, 1);
            this.Tlp_avance.Controls.Add(this.Pic_barra1, 2, 1);
            this.Tlp_avance.Controls.Add(this.Pic_barra2, 4, 1);
            this.Tlp_avance.Controls.Add(this.Pic_barra3, 6, 1);
            this.Tlp_avance.Controls.Add(this.Pic_barra4, 8, 1);
            this.Tlp_avance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tlp_avance.Location = new System.Drawing.Point(4, 189);
            this.Tlp_avance.Margin = new System.Windows.Forms.Padding(4);
            this.Tlp_avance.Name = "Tlp_avance";
            this.Tlp_avance.RowCount = 3;
            this.Tlp_avance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.Tlp_avance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Tlp_avance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.Tlp_avance.Size = new System.Drawing.Size(1391, 130);
            this.Tlp_avance.TabIndex = 2;
            // 
            // Pic_no2
            // 
            this.Pic_no2.BackgroundImage = global::procesoeEntregaDePasaporte.Properties.Resources.two;
            this.Pic_no2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_no2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_no2.Location = new System.Drawing.Point(502, 39);
            this.Pic_no2.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_no2.Name = "Pic_no2";
            this.Pic_no2.Size = new System.Drawing.Size(76, 65);
            this.Pic_no2.TabIndex = 0;
            this.Pic_no2.TabStop = false;
            // 
            // Pic_no3
            // 
            this.Pic_no3.BackgroundImage = global::procesoeEntregaDePasaporte.Properties.Resources.three;
            this.Pic_no3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_no3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_no3.Location = new System.Drawing.Point(654, 39);
            this.Pic_no3.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_no3.Name = "Pic_no3";
            this.Pic_no3.Size = new System.Drawing.Size(76, 65);
            this.Pic_no3.TabIndex = 2;
            this.Pic_no3.TabStop = false;
            // 
            // Pic_no4
            // 
            this.Pic_no4.BackgroundImage = global::procesoeEntregaDePasaporte.Properties.Resources.four;
            this.Pic_no4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_no4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_no4.Location = new System.Drawing.Point(806, 39);
            this.Pic_no4.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_no4.Name = "Pic_no4";
            this.Pic_no4.Size = new System.Drawing.Size(76, 65);
            this.Pic_no4.TabIndex = 3;
            this.Pic_no4.TabStop = false;
            // 
            // Pic_no5
            // 
            this.Pic_no5.BackgroundImage = global::procesoeEntregaDePasaporte.Properties.Resources.five;
            this.Pic_no5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_no5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_no5.Location = new System.Drawing.Point(958, 39);
            this.Pic_no5.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_no5.Name = "Pic_no5";
            this.Pic_no5.Size = new System.Drawing.Size(76, 65);
            this.Pic_no5.TabIndex = 4;
            this.Pic_no5.TabStop = false;
            // 
            // Pic_no1
            // 
            this.Pic_no1.BackgroundImage = global::procesoeEntregaDePasaporte.Properties.Resources.one;
            this.Pic_no1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_no1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_no1.Location = new System.Drawing.Point(350, 39);
            this.Pic_no1.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_no1.Name = "Pic_no1";
            this.Pic_no1.Size = new System.Drawing.Size(76, 65);
            this.Pic_no1.TabIndex = 1;
            this.Pic_no1.TabStop = false;
            // 
            // Pic_barra1
            // 
            this.Pic_barra1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Pic_barra1.BackgroundImage")));
            this.Pic_barra1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_barra1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_barra1.Location = new System.Drawing.Point(426, 39);
            this.Pic_barra1.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_barra1.Name = "Pic_barra1";
            this.Pic_barra1.Size = new System.Drawing.Size(76, 65);
            this.Pic_barra1.TabIndex = 5;
            this.Pic_barra1.TabStop = false;
            // 
            // Pic_barra2
            // 
            this.Pic_barra2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Pic_barra2.BackgroundImage")));
            this.Pic_barra2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_barra2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_barra2.Location = new System.Drawing.Point(578, 39);
            this.Pic_barra2.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_barra2.Name = "Pic_barra2";
            this.Pic_barra2.Size = new System.Drawing.Size(76, 65);
            this.Pic_barra2.TabIndex = 6;
            this.Pic_barra2.TabStop = false;
            // 
            // Pic_barra3
            // 
            this.Pic_barra3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Pic_barra3.BackgroundImage")));
            this.Pic_barra3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_barra3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_barra3.Location = new System.Drawing.Point(730, 39);
            this.Pic_barra3.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_barra3.Name = "Pic_barra3";
            this.Pic_barra3.Size = new System.Drawing.Size(76, 65);
            this.Pic_barra3.TabIndex = 7;
            this.Pic_barra3.TabStop = false;
            // 
            // Pic_barra4
            // 
            this.Pic_barra4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Pic_barra4.BackgroundImage")));
            this.Pic_barra4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_barra4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_barra4.Location = new System.Drawing.Point(882, 39);
            this.Pic_barra4.Margin = new System.Windows.Forms.Padding(0);
            this.Pic_barra4.Name = "Pic_barra4";
            this.Pic_barra4.Size = new System.Drawing.Size(76, 65);
            this.Pic_barra4.TabIndex = 8;
            this.Pic_barra4.TabStop = false;
            // 
            // Tlp_area_info
            // 
            this.Tlp_area_info.ColumnCount = 3;
            this.Tlp_area_info.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.Tlp_area_info.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.Tlp_area_info.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.Tlp_area_info.Controls.Add(this.Lbl_no_paso, 1, 0);
            this.Tlp_area_info.Controls.Add(this.Tlp_Informacion, 1, 1);
            this.Tlp_area_info.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tlp_area_info.Location = new System.Drawing.Point(4, 327);
            this.Tlp_area_info.Margin = new System.Windows.Forms.Padding(4);
            this.Tlp_area_info.Name = "Tlp_area_info";
            this.Tlp_area_info.RowCount = 2;
            this.Tlp_area_info.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.Tlp_area_info.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.Tlp_area_info.Size = new System.Drawing.Size(1391, 595);
            this.Tlp_area_info.TabIndex = 3;
            // 
            // Lbl_no_paso
            // 
            this.Lbl_no_paso.AutoSize = true;
            this.Lbl_no_paso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_no_paso.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_no_paso.ForeColor = System.Drawing.Color.Black;
            this.Lbl_no_paso.Location = new System.Drawing.Point(73, 0);
            this.Lbl_no_paso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_no_paso.Name = "Lbl_no_paso";
            this.Lbl_no_paso.Size = new System.Drawing.Size(1243, 59);
            this.Lbl_no_paso.TabIndex = 0;
            this.Lbl_no_paso.Text = "Paso 5 de 5";
            this.Lbl_no_paso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tlp_Informacion
            // 
            this.Tlp_Informacion.ColumnCount = 3;
            this.Tlp_Informacion.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.53846F));
            this.Tlp_Informacion.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 76.92308F));
            this.Tlp_Informacion.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.53846F));
            this.Tlp_Informacion.Controls.Add(this.Lbl_paso_actual, 1, 0);
            this.Tlp_Informacion.Controls.Add(this.Lbl_descripcion_paso, 1, 1);
            this.Tlp_Informacion.Controls.Add(this.Pic_imagen_pasaporte, 1, 2);
            this.Tlp_Informacion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tlp_Informacion.Location = new System.Drawing.Point(73, 63);
            this.Tlp_Informacion.Margin = new System.Windows.Forms.Padding(4);
            this.Tlp_Informacion.Name = "Tlp_Informacion";
            this.Tlp_Informacion.RowCount = 3;
            this.Tlp_Informacion.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.Tlp_Informacion.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.66667F));
            this.Tlp_Informacion.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.66667F));
            this.Tlp_Informacion.Size = new System.Drawing.Size(1243, 528);
            this.Tlp_Informacion.TabIndex = 1;
            // 
            // Lbl_paso_actual
            // 
            this.Lbl_paso_actual.AutoSize = true;
            this.Lbl_paso_actual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_paso_actual.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_paso_actual.ForeColor = System.Drawing.Color.Black;
            this.Lbl_paso_actual.Location = new System.Drawing.Point(147, 0);
            this.Lbl_paso_actual.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_paso_actual.Name = "Lbl_paso_actual";
            this.Lbl_paso_actual.Size = new System.Drawing.Size(948, 88);
            this.Lbl_paso_actual.TabIndex = 0;
            this.Lbl_paso_actual.Text = "Su pasaporte ya se encuentra impreso";
            this.Lbl_paso_actual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl_descripcion_paso
            // 
            this.Lbl_descripcion_paso.AutoSize = true;
            this.Lbl_descripcion_paso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_descripcion_paso.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.Lbl_descripcion_paso.ForeColor = System.Drawing.Color.Black;
            this.Lbl_descripcion_paso.Location = new System.Drawing.Point(147, 88);
            this.Lbl_descripcion_paso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_descripcion_paso.Name = "Lbl_descripcion_paso";
            this.Lbl_descripcion_paso.Size = new System.Drawing.Size(948, 219);
            this.Lbl_descripcion_paso.TabIndex = 1;
            this.Lbl_descripcion_paso.Text = "Por favor pasar a traer su pasaporte y verificar si los datos fueron correctament" +
    "e impresos.";
            this.Lbl_descripcion_paso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Pic_imagen_pasaporte
            // 
            this.Pic_imagen_pasaporte.BackgroundImage = global::procesoeEntregaDePasaporte.Properties.Resources.ejemploPasaporte;
            this.Pic_imagen_pasaporte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_imagen_pasaporte.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pic_imagen_pasaporte.Location = new System.Drawing.Point(147, 311);
            this.Pic_imagen_pasaporte.Margin = new System.Windows.Forms.Padding(4);
            this.Pic_imagen_pasaporte.Name = "Pic_imagen_pasaporte";
            this.Pic_imagen_pasaporte.Size = new System.Drawing.Size(948, 213);
            this.Pic_imagen_pasaporte.TabIndex = 2;
            this.Pic_imagen_pasaporte.TabStop = false;
            // 
            // Tlp_entrega_pasaporte
            // 
            this.Tlp_entrega_pasaporte.ColumnCount = 1;
            this.Tlp_entrega_pasaporte.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Tlp_entrega_pasaporte.Controls.Add(this.Tlp_area_info, 0, 2);
            this.Tlp_entrega_pasaporte.Controls.Add(this.Tlp_avance, 0, 1);
            this.Tlp_entrega_pasaporte.Controls.Add(this.Tlp_titulo, 0, 0);
            this.Tlp_entrega_pasaporte.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tlp_entrega_pasaporte.Location = new System.Drawing.Point(0, 0);
            this.Tlp_entrega_pasaporte.Margin = new System.Windows.Forms.Padding(4);
            this.Tlp_entrega_pasaporte.Name = "Tlp_entrega_pasaporte";
            this.Tlp_entrega_pasaporte.RowCount = 3;
            this.Tlp_entrega_pasaporte.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.Tlp_entrega_pasaporte.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.Tlp_entrega_pasaporte.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.Tlp_entrega_pasaporte.Size = new System.Drawing.Size(1399, 926);
            this.Tlp_entrega_pasaporte.TabIndex = 0;
            // 
            // Frm_recepcion_de_pasaportes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1399, 926);
            this.ControlBox = false;
            this.Controls.Add(this.Tlp_entrega_pasaporte);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Frm_recepcion_de_pasaportes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Tlp_titulo.ResumeLayout(false);
            this.Tlp_titulo.PerformLayout();
            this.Tlp_avance.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_no1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_barra4)).EndInit();
            this.Tlp_area_info.ResumeLayout(false);
            this.Tlp_area_info.PerformLayout();
            this.Tlp_Informacion.ResumeLayout(false);
            this.Tlp_Informacion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_imagen_pasaporte)).EndInit();
            this.Tlp_entrega_pasaporte.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel Tlp_titulo;
        private System.Windows.Forms.Label lbl_Titulo1;
        private System.Windows.Forms.TableLayoutPanel Tlp_avance;
        private System.Windows.Forms.PictureBox Pic_no2;
        private System.Windows.Forms.PictureBox Pic_no3;
        private System.Windows.Forms.PictureBox Pic_no4;
        private System.Windows.Forms.PictureBox Pic_no5;
        private System.Windows.Forms.PictureBox Pic_no1;
        private System.Windows.Forms.PictureBox Pic_barra1;
        private System.Windows.Forms.PictureBox Pic_barra2;
        private System.Windows.Forms.PictureBox Pic_barra3;
        private System.Windows.Forms.PictureBox Pic_barra4;
        private System.Windows.Forms.TableLayoutPanel Tlp_area_info;
        private System.Windows.Forms.Label Lbl_no_paso;
        private System.Windows.Forms.TableLayoutPanel Tlp_Informacion;
        private System.Windows.Forms.Label Lbl_paso_actual;
        private System.Windows.Forms.Label Lbl_descripcion_paso;
        private System.Windows.Forms.PictureBox Pic_imagen_pasaporte;
        private System.Windows.Forms.TableLayoutPanel Tlp_entrega_pasaporte;
    }
}

